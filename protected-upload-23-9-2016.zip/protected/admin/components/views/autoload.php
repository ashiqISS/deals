
<input type="text" class="form-control" name="<?= '_dummuy' ?>" >
<input type="hidden" class="form-control" name="<?= $this->field_name ?>">

<?php //echo $form->hiddenField($this->model, $this->field_name, array('size' => 60, 'maxlength' => 225, 'class' => 'form-control')); ?>

